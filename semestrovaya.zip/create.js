const db = db.getSiblingDB('med_db');

function createCollectionWithSchema(collectionName, schema) {
    db.createCollection(collectionName, {
        validator: {
            $jsonSchema: schema
        },
        validationLevel: "strict"
    });
}

const hospitalsSchema = {
    bsonType: "object",
    required: ["_id", "name", "address", "departments"],
    properties: {
        "_id": { bsonType: "objectId" },
        "name": { bsonType: "string" },
        "address": { bsonType: "string" },
        "departments": {
            bsonType: "array",
            items: {
                bsonType: "object",
                required: ["_id", "name", "headId", "wards"],
                properties: {
                    "_id": { bsonType: "objectId" },
                    "name": { bsonType: "string" },
                    "headId": { bsonType: "objectId" },
                    "wards": {
                        bsonType: "array",
                        items: {
                            bsonType: "object",
                            required: ["_id", "name", "capacity"],
                            properties: {
                                "_id": { bsonType: "objectId" },
                                "name": { bsonType: "string" },
                                "capacity": { bsonType: "int" },
								"occupiedBeds": { bsonType: "int" }
                            }
                        }
                    }
                }
            }
        }
    }
};

const polyclinicsSchema = {
    bsonType: "object",
    required: ["_id", "name", "address", "departments"],
    properties: {
        "_id": { bsonType: "objectId" },
        "name": { bsonType: "string" },
        "address": { bsonType: "string" },
        "attached_hospital_id": {bsonType: ["objectId", "null"]},
        "departments": {
            bsonType: "array",
            items: {
                bsonType: "object",
                required: ["_id", "name", "headId", "cabinets"],
                properties: {
                    "_id": { bsonType: "objectId" },
                    "name": { bsonType: "string" },
                    "headId": { bsonType: "objectId" },
                    "cabinets": {
                        bsonType: "array",
                        items: {
                            bsonType: "object",
                            required: ["number", "purpose"],
                            properties: {
                                "number": { bsonType: "string" },
                                "purpose": { bsonType: "string" }
                            }
                        }
                    }
                }
            }
        }
    }
};

const staffSchema = {
    bsonType: "object",
    required: ["_id", "firstName", "lastName", "specialty", "assignments", "education"],
    properties: {
        "_id": { bsonType: "objectId" },
        "firstName": { bsonType: "string" },
        "lastName": { bsonType: "string" },
        "specialty": { bsonType: "string" },
        "assignments": {
            bsonType: "array",
            items: {
                bsonType: "object",
                required: ["organizationId", "organizationType", "role", "startDate"],
                properties: {
                    "organizationId": { bsonType: "objectId" },
                    "organizationType": { enum: ["hospital", "polyclinic"], bsonType: "string" },
                    "role": { bsonType: "string" },
                    "startDate": { bsonType: "date" }
                }
            }
        },
        "education": {
            bsonType: "array",
            items: {
                bsonType: "object",
                required: ["degree", "institution", "year"],
                properties: {
                    "degree": { bsonType: "string" },
                    "institution": { bsonType: "string" },
                    "year": { bsonType: "int" }
                }
            }
        }
    }
};

const laboratoriesSchema = {
    bsonType: "object",
    properties: {
        "_id": { bsonType: "objectId" },
        "name": { bsonType: "string" },
        "address": { bsonType: "string" },
        "profiles": {
            bsonType: "array",
            items: { bsonType: "string" }
        },
        "services": {
            bsonType: "array",
            items: {
                bsonType: "object",
                required: ["name", "price"],
                properties: {
                    "name": { bsonType: "string" },
                    "price": { bsonType: "double" }
                }
            }
        },
        "managerId": { bsonType: "objectId" }
    }
};

const patientsSchema = {
    bsonType: "object",
    required: ["_id", "firstName", "lastName", "birthDate", "gender", "registrations", "doctorId"],
    properties: {
        "_id": { bsonType: "objectId" },
        "firstName": { bsonType: "string" },
        "lastName": { bsonType: "string" },
        "birthDate": { bsonType: "date" },
        "gender": { bsonType: "string" },
        "registrations": {
            bsonType: "array",
            items: {
                bsonType: "object",
                required: ["organizationId", "organizationType", "registrationDate"],
                properties: {
                    "organizationId": { bsonType: "objectId" },
                    "organizationType": { enum: ["hospital", "polyclinic"], bsonType: "string" },
                    "registrationDate": { bsonType: "date" }
                }
            }
        },
        "doctorId": { bsonType: "objectId" }
    }
};

const labContactsSchema = {
    bsonType: "object",
    properties: {
        "_id": { bsonType: "objectId" },
        "laboratoryId": { bsonType: "objectId" },
        "organizationId": { bsonType: "objectId" },
        "organizationType": { enum: ["hospital", "polyclinic"], bsonType: "string" },
        "startDate": { bsonType: "date" },
        "endDate": { bsonType: ["date", "null"] },
        "analysisType": { bsonType: "string" },
        "signedBy": { bsonType: "objectId" },
        "status": { enum: ["Active", "Expired", "Suspended"], bsonType: "string" }
    }
};

const medicalHistorySchema = {
    bsonType: "object",
    required: ["_id", "patientId", "visitDate", "type", "doctorId", "organizationId", "organizationType", "cabinetNumber", "diagnoses", "treatments", "operations", "labTests"],
    properties: {
        "_id": { bsonType: "objectId" },
        "patientId": { bsonType: "objectId" },
        "visitDate": { bsonType: "date" },
        "type": { bsonType: "string" },
        "doctorId": { bsonType: "objectId" },
        "organizationId": { bsonType: "objectId" },
        "organizationType": { enum: ["hospital", "polyclinic"], bsonType: "string" },
        "cabinetNumber": { bsonType: "string" },
        "hospitalizations": {
            bsonType: "array",
            items: {
                bsonType: "object",
                required: ["hospitalId", "doctorId", "admission_date", "discharge_date"],
                properties: {
                    "hospitalId": { bsonType: "objectId" },
                    "doctorId": { bsonType: "objectId" },
                    "admission_date": { bsonType: "date" },
                    "discharge_date": { bsonType: "date" }
                }
            }
        },
        "diagnoses": {
            bsonType: "array",
            items: {
                bsonType: "object",
                required: ["description"],
                properties: {
                    "description": { bsonType: "string" }
                }
            }
        },
        "treatments": {
            bsonType: "array",
            items: {
                bsonType: "object",
                required: ["medicine", "dosage", "duration"],
                properties: {
                    "medicine": { bsonType: "string" },
                    "dosage": { bsonType: "string" },
                    "duration": { bsonType: "string" }
                }
            }
        },
        "operations": {
            bsonType: "array",
            items: {
                bsonType: "object",
                required: ["doctorId", "procedure", "date"],
                properties: {
                    "doctorId": { bsonType: "objectId" },
                    "procedure": { bsonType: "string" },
                    "date": { bsonType: "date" }
                }
            }
        },
        "labTests": {
            bsonType: "array",
            items: {
                bsonType: "object",
                required: ["contractId"],
                properties: {
                    "contractId": { bsonType: "objectId" }
                }
            }
        }
    }
};


createCollectionWithSchema("hospitals", hospitalsSchema);
createCollectionWithSchema("polyclinics", polyclinicsSchema);
createCollectionWithSchema("staff", staffSchema); 
//createCollectionWithSchema("laboratories", laboratoriesSchema);
db.createCollection("laboratories");
createCollectionWithSchema("patients", patientsSchema);
//createCollectionWithSchema("lab_contacts", labContactsSchema);
db.createCollection("lab_contacts");
createCollectionWithSchema("medical_history", medicalHistorySchema);