use('med_db');


const collections = db.getCollectionNames();
collections.forEach(name => {
    db[name].deleteMany({}); 
});



function generateObjectId() {
    return new ObjectId();
}

// Функция для генерации случайной даты (до сегодняшней)
function randomDate(start, end) {
    const date = new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
    return date;
}

// Больницы (минимум 2)
const hospitals = [
    {
        _id: generateObjectId(),
        name: "Городская больница №1",
        address: "ул. Ленина, 10",
        departments: [
            {
                _id: generateObjectId(),
                name: "Хирургия",
                headId: generateObjectId(), // Заполним позже после создания staff
                wards: [
                    { _id: generateObjectId(), name: "Палата 101", capacity: 4, occupiedBeds: 2 },
                    { _id: generateObjectId(), name: "Палата 102", capacity: 6, occupiedBeds: 0 },
                    { _id: generateObjectId(), name: "Палата 103", capacity: 5, occupiedBeds: 5 }
                ]
            },
            {
                _id: generateObjectId(),
                name: "Терапия",
                headId: generateObjectId(),
                wards: [
                    { _id: generateObjectId(), name: "Палата 201", capacity: 8, occupiedBeds: 6 },
                    { _id: generateObjectId(), name: "Палата 202", capacity: 4, occupiedBeds: 0 }
                ]
            }
        ]
    },
    {
        _id: generateObjectId(),
        name: "Центральная больница",
        address: "пр. Победы, 25",
        departments: [
            {
                _id: generateObjectId(),
                name: "Офтальмология",
                headId: generateObjectId(),
                wards: [
                    { _id: generateObjectId(), name: "Палата 301", capacity: 6, occupiedBeds: 4 },
                    { _id: generateObjectId(), name: "Палата 302", capacity: 5, occupiedBeds: 0 }
                ]
            },
            {
                _id: generateObjectId(),
                name: "Невропатология",
                headId: generateObjectId(),
                wards: [
                    { _id: generateObjectId(), name: "Палата 401", capacity: 7, occupiedBeds: 7 },
                    { _id: generateObjectId(), name: "Палата 402", capacity: 4, occupiedBeds: 2 }
                ]
            }
        ]
    }
];

// Поликлиники (6: 4 привязаны к больницам, 2 не привязаны)
const polyclinics = [
    {
        _id: generateObjectId(),
        name: "Поликлиника №1",
        address: "ул. Кирова, 5",
        attached_hospital_id: hospitals[0]._id,
        departments: [
            {
                _id: generateObjectId(),
                name: "Терапевтическое отделение",
                headId: generateObjectId(),
                cabinets: [
                    { number: "101", purpose: "Терапевт" },
                    { number: "102", purpose: "Сестра" }
                ]
            },
            {
                _id: generateObjectId(),
                name: "Офтальмологическое отделение",
                headId: generateObjectId(),
                cabinets: [
                    { number: "201", purpose: "Окулист" }
                ]
            }
        ]
    },
    {
        _id: generateObjectId(),
        name: "Поликлиника №2",
        address: "ул. Гагарина, 15",
        attached_hospital_id: hospitals[1]._id,
        departments: [
            {
                _id: generateObjectId(),
                name: "Хирургическое отделение",
                headId: generateObjectId(),
                cabinets: [
                    { number: "301", purpose: "Хирург" }
                ]
            }
        ]
    },
    {
        _id: generateObjectId(),
        name: "Поликлиника №3",
        address: "пр. Ленина, 40",
        attached_hospital_id: hospitals[0]._id,
        departments: [
            {
                _id: generateObjectId(),
                name: "Невропатологическое отделение",
                headId: generateObjectId(),
                cabinets: [
                    { number: "401", purpose: "Невропатолог" }
                ]
            }
        ]
    },
    {
        _id: generateObjectId(),
        name: "Поликлиника №4",
        address: "ул. Пушкина, 2",
        attached_hospital_id: hospitals[1]._id,
        departments: [
            {
                _id: generateObjectId(),
                name: "Стоматологическое отделение",
                headId: generateObjectId(),
                cabinets: [
                    { number: "501", purpose: "Стоматолог" }
                ]
            }
        ]
    },
    {
        _id: generateObjectId(),
        name: "Поликлиника №5",
        address: "ул. Мира, 7",
        attached_hospital_id: null, // Не привязана
        departments: [
            {
                _id: generateObjectId(),
                name: "Гинекологическое отделение",
                headId: generateObjectId(),
                cabinets: [
                    { number: "601", purpose: "Гинеколог" }
                ]
            }
        ]
    },
    {
        _id: generateObjectId(),
        name: "Поликлиника №6",
        address: "пр. Кирова, 12",
        attached_hospital_id: null, // Не привязана
        departments: [
            {
                _id: generateObjectId(),
                name: "Рентгенологическое отделение",
                headId: generateObjectId(),
                cabinets: [
                    { number: "701", purpose: "Рентгенолог" }
                ]
            }
        ]
    }
];

// Персонал (35-45 человек)
const staffIds = Array.from({ length: 40 }, () => generateObjectId());
const staff = staffIds.map((id, index) => {
    const specialties = ["Хирург", "Стоматолог", "Гинеколог", "Терапевт", "Невропатолог", "Окулист", "Рентгенолог"];
    const specialty = specialties[Math.floor(Math.random() * specialties.length)];
    const organizations = [...hospitals.map(h => ({ id: h._id, type: "hospital" })), ...polyclinics.map(p => ({ id: p._id, type: "polyclinic" }))];
    const assignments = [];
    const numAssignments = Math.floor(Math.random() * 2) + 1; // 1-2 assignments
    for (let i = 0; i < numAssignments; i++) {
        const org = organizations[Math.floor(Math.random() * organizations.length)];
        assignments.push({
            organizationId: org.id,
            organizationType: org.type,
            role: specialty + " " + (Math.random() > 0.5 ? "Заведующий" : "Врач"),
            startDate: randomDate(new Date(2020, 0, 1), new Date())
        });
    }
    const degrees = ["Кандидат медицинских наук", "Доктор медицинских наук", ""];
    const degree = degrees[Math.floor(Math.random() * degrees.length)];
    const education = degree ? [{
        degree: degree,
        institution: "Медицинский университет",
        year: Math.floor(Math.random() * 30) + 1995
    }] : [];
    return {
        _id: id,
        firstName: "Имя" + (index + 1),
        lastName: "Фамилия" + (index + 1),
        specialty: specialty,
        assignments: assignments,
        education: education
    };
});

// Теперь обновим headId в departments с реальными staff
hospitals.forEach(h => {
    h.departments.forEach(d => {
        d.headId = staff[Math.floor(Math.random() * staff.length)]._id;
    });
});
polyclinics.forEach(p => {
    p.departments.forEach(d => {
        d.headId = staff[Math.floor(Math.random() * staff.length)]._id;
    });
});

// Лаборатории (3)
const laboratories = [
    {
        _id: generateObjectId(),
        name: "Биохимлаб",
        address: "ул. Лабор, 1",
        profiles: ["Биохимические", "Физиологические"],
        services: [
            { name: "Анализ крови", price: 500.0 },
            { name: "Биохимический анализ", price: 800.0 }
        ],
        managerId: staff[0]._id
    },
    {
        _id: generateObjectId(),
        name: "Химлаб",
        address: "ул. Лабор, 2",
        profiles: ["Химические"],
        services: [
            { name: "Химический анализ", price: 600.0 }
        ],
        managerId: staff[1]._id
    },
    {
        _id: generateObjectId(),
        name: "Медлаб",
        address: "ул. Лабор, 3",
        profiles: ["Биохимические", "Химические"],
        services: [
            { name: "Физиологический анализ", price: 700.0 }
        ],
        managerId: staff[2]._id
    }
];

// Контракты лабораторий (некоторые labs обслуживают некоторые orgs)
const lab_contacts = [];
laboratories.forEach(lab => {
    const orgs = [...hospitals, ...polyclinics].slice(0, 5); // Подключим к 5 org
    orgs.forEach(org => {
        lab_contacts.push({
            _id: generateObjectId(),
            laboratoryId: lab._id,
            organizationId: org._id,
            organizationType: org.name.includes("больница") ? "hospital" : "polyclinic",
            startDate: randomDate(new Date(2023, 0, 1), new Date()),
            endDate: Math.random() > 0.5 ? randomDate(new Date(2026, 0, 1), new Date(2030, 0, 1)) : null,
            analysisType: lab.services[0].name,
            signedBy: staff[Math.floor(Math.random() * staff.length)]._id,
            status: ["Active", "Expired", "Suspended"][Math.floor(Math.random() * 3)]
        });
    });
});

// Пациенты (200)
const patients = [];
for (let i = 0; i < 200; i++) {
    const registrations = [];
    const numRegs = Math.floor(Math.random() * 2) + 1;
    for (let j = 0; j < numRegs; j++) {
        const org = polyclinics[Math.floor(Math.random() * polyclinics.length)];
        registrations.push({
            organizationId: org._id,
            organizationType: "polyclinic",
            registrationDate: randomDate(new Date(2020, 0, 1), new Date())
        });
    }
    patients.push({
        _id: generateObjectId(),
        firstName: "Пациент" + (i + 1),
        lastName: "ФамилияП" + (i + 1),
        birthDate: randomDate(new Date(1950, 0, 1), new Date(2005, 0, 1)),
        gender: Math.random() > 0.5 ? "Мужской" : "Женский",
        registrations: registrations,
        doctorId: staff[Math.floor(Math.random() * staff.length)]._id
    });
}

// Медицинская история (для каждого пациента хотя бы одна запись, некоторые с hospitalizations, operations)
const medical_history = [];
patients.forEach((p, index) => {
    const numVisits = Math.floor(Math.random() * 5) + 1;
    for (let k = 0; k < numVisits; k++) {
        const org = polyclinics[Math.floor(Math.random() * polyclinics.length)]; // Поликлиника для амбулаторного
        const hospitalization = Math.random() > 0.7 ? {
            hospitalId: hospitals[Math.floor(Math.random() * hospitals.length)]._id,
            doctorId: (function() {
                const surgicalStaff = staff.filter(s => ["Хирург", "Стоматолог", "Гинеколог"].includes(s.specialty));
                return surgicalStaff.length > 0 ? surgicalStaff[Math.floor(Math.random() * surgicalStaff.length)]._id : staff[0]._id;
            })(),
            admission_date: randomDate(new Date(2023, 0, 1), new Date(2025, 11, 23)),
            discharge_date: randomDate(new Date(2025, 11, 23), new Date()) // Некоторые уже выписаны
        } : null;
        const operations = Math.random() > 0.8 && hospitalization ? [{
            doctorId: (function() {
                const surgicalStaff = staff.filter(s => ["Хирург", "Стоматолог", "Гинеколог"].includes(s.specialty));
                return surgicalStaff.length > 0 ? surgicalStaff[Math.floor(Math.random() * surgicalStaff.length)]._id : staff[0]._id;
            })(),
            procedure: "Операция " + Math.random().toString(36).substring(7),
            date: randomDate(new Date(2025, 11, 1), new Date()) // Исправлено: randomDate вместо _randomDate
        }] : [];
        medical_history.push({
            _id: generateObjectId(),
            patientId: p._id,
            visitDate: randomDate(new Date(2020, 0, 1), new Date()),
            type: "Амбулаторный прием",
            doctorId: p.doctorId,
            organizationId: org._id,
            organizationType: "polyclinic",
            cabinetNumber: org.departments[0].cabinets[0].number,
            hospitalizations: hospitalization ? [hospitalization] : [],
            diagnoses: [{ description: "Диагноз " + Math.random().toString(36).substring(7) }],
            treatments: [{ medicine: "Лекарство " + Math.random().toString(36).substring(7), dosage: "1 раз в день", duration: "7 дней" }],
            operations: operations,
            labTests: lab_contacts.slice(0, Math.floor(Math.random() * 3)).map(lc => ({ contractId: lc._id }))
        });
    }
});

// Теперь заполним палаты на основе hospitalizations (для пациентов, которые все еще госпитализированы или нет)
hospitals.forEach(h => {
    h.departments.forEach(d => {
        d.wards.forEach(w => {
            if (w.occupiedBeds < w.capacity && Math.random() > 0.5) {
                // Добавим пациентов (упрощенно, не проверяя даты, предполагаем некоторые заняты)
                // В реальности, нужно совпадать с actual hospitalizations
                // Для этого примера, оставим как есть, подразумевая обновление occupiedBeds на основе историй
            }
        });
    });
});

// Вставка данных
db.hospitals.insertMany(hospitals);
db.polyclinics.insertMany(polyclinics);
db.staff.insertMany(staff);
db.laboratories.insertMany(laboratories);
db.lab_contacts.insertMany(lab_contacts);
db.patients.insertMany(patients);
db.medical_history.insertMany(medical_history);






